<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include("header-links.php") ?>
</head>
<body>
    <?php include("guest/header.php") ?>
    <?php include("guest/register.php") ?>
</body>
</html>