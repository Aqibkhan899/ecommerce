<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Add New Product</h4>
                </div>

                <div class="card-body">

                    <form action="" method="POST" enctype="multipart/form-data">

                        <select class="form-control" name="category_id" required>
                            <option value="">-- Select Category--</option>
                            <?php
                                include("connect.php");
                                $result=mysqli_query($conn,"SELECT * FROM categories");
                                while($row=mysqli_fetch_assoc($result)){
                                    echo "<option value='".$row['category_id']."'>".$row['name']."</option>";
                                }
                            ?>
                        </select>

                        <!-- Product Name -->
                        <div class="mb-3">
                            <label class="form-label">Product Name</label>
                            <input type="text"
                                   name="name"
                                   class="form-control"
                                   placeholder="Enter Product Name"
                                   required>
                        </div>

                        <!-- Description -->
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description"
                                      class="form-control"
                                      rows="3"
                                      placeholder="Enter Product Description"
                                      required></textarea>
                        </div>

                        <!-- Price -->
                        <div class="mb-3">
                            <label class="form-label">Price</label>
                            <input type="number"
                                   name="price"
                                   class="form-control"
                                   placeholder="Enter Product Price"
                                   min="0"
                                   step="0.01"
                                   required>
                        </div>

                        <!-- Stock -->
                        <div class="mb-3">
                            <label class="form-label">Stock</label>
                            <input type="number"
                                   name="stock"
                                   class="form-control"
                                   placeholder="Enter Stock Quantity"
                                   min="0"
                                   required>
                        </div>

                        <!-- Image -->
                        <div class="mb-3">
                            <label class="form-label">Product Image</label>
                            <input type="file"
                                   name="image"
                                   class="form-control"
                                   accept="image/*"
                                   required>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" name="save" class="btn btn-primary w-100">
                            Add Product
                        </button>

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

<?php
    include("connect.php");
    if(isset($_POST['save'])){
        $category_id=$_POST['category_id'];
        $name=$_POST['name'];
        $description=$_POST['description'];
        $price=str_replace(',','',$_POST['price']); //12,000 --> 12000
        $stock=$_POST['stock'];
        $image=$_FILES['image']['name'];
        $tmpimage=$_FILES['image']['tmp_name'];
        $folder="upload/";
        if(move_uploaded_file($tmpimage, $folder . $image)){
            $query="insert into products(category_id,name,description,price,stock,image)values('$category_id','$name','$description','$price','$stock','$image')";
            $run=mysqli_query($conn,$query);
            
        }
    }

?>