<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Add New Category</h4>
                </div>

                <div class="card-body">

                    <form action="" method="POST">

                        <!-- Category Name -->
                        <div class="mb-3">
                            <label class="form-label">
                                Category Name
                            </label>
                            <input
                                type="text"
                                name="categoryname"
                                class="form-control"
                                placeholder="Enter Category Name"
                                required
                            >
                        </div>

                        <!-- Category Description -->
                        <div class="mb-3">
                            <label class="form-label">
                                Category Description
                            </label>
                            <textarea
                                name="categorydescription"
                                class="form-control"
                                rows="4"
                                placeholder="Enter Category Description"
                                required
                            ></textarea>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" name="save" class="btn btn-primary w-100">
                            Add Category
                        </button>

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

<?php
     include("connect.php");
     if(isset($_POST['save'])){
        $categoryname=$_POST['categoryname'];
        $categorydescription=$_POST['categorydescription'];
        $query="insert into categories(name,description)values('$categoryname','$categorydescription')";
        $run=mysqli_query($conn,$query);
        if($run){
            echo "<script>alert('Category Successfully added')</script>";
        }else{
           echo "<script>alert('Category Not added')</script>"; 
        }
     }
?>