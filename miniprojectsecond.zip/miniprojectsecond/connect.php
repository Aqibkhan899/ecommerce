<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $databasename = "ecommerceproject";

  $conn=mysqli_connect($servername,$username,$password,$databasename);
  if(!$conn){
    die ("connection error" . mysqli_error());
  }
//   else{
//     echo "Connected";
//   }
?>