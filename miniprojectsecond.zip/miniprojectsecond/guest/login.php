<?php
    session_start();
?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">

            <div class="card shadow">
                <div class="card-header bg-success text-white text-center">
                    <h3>Login Form</h3>
                </div>

                <div class="card-body">

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control"
                                placeholder="Enter your email" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control"
                                placeholder="Enter your password" required>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="checkbox" name="rememberme" class="form-check-input" id="remember">
                            <label class="form-check-label" for="remember">
                                Remember Me
                            </label>
                        </div>

                        <button type="submit" name="login" class="btn btn-success w-100">
                            Login
                        </button>
                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

<?php
    include("connect.php");
    if(isset($_POST['login'])){
        $email=$_POST['email'];
        $password=$_POST['password'];
        $query="select * from users where email='$email' and password='$password'";
        $run=mysqli_query($conn,$query);
        $row=mysqli_num_rows($run);
        if($row>0){
            while($data=mysqli_fetch_array($run)){
                if(isset($_POST['rememberme'])){
                    setcookie('useremail', $email, time()+60*60*24*2);
                    setcookie('userpassword', $password, time()+60*60*24*2);
                }else{
                    setcookie('useremail', $email, time()-600000000);
                    setcookie('userpassword', $password, time()-600000000);
                }
                echo "<script>alert('Login')</script>";
                if($data['role']=='admin'){
                    $_SESSION["name"]=$data['name'];
                    echo "<script>window.location.href='admindash.php'</script>";
                }
                else if($data['role']=='customer'){
                    $_SESSION["name"]=$data['name'];
                    echo "<script>window.location.href='userdash.php'</script>";
                }
            }
        }
    }

?>