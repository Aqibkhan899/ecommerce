<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card shadow">
                <div class="card-header bg-primary text-white text-center">
                    <h3>Registration Form</h3>
                </div>

                <div class="card-body">

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name"
                                placeholder="Enter your name" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control"
                                placeholder="Enter your email" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control"
                                placeholder="Enter your password" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Phone</label>
                            <input type="tel" name="number" class="form-control"
                                placeholder="Enter your phone number" required>
                        </div>
                        <input type="hidden" value="customer" name="roletype">

                        <button type="submit" name="submit" class="btn btn-primary w-100">
                            Register
                        </button>
                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

<?php 
    include("connect.php");
    if(isset($_POST['submit'])){
        $name=$_POST['name'];
        $email=$_POST['email'];
        $password=$_POST['password'];
        $number=$_POST['number'];
        $roletype=$_POST['roletype'];
        $select="select * from users where email='$email'";
        $result=mysqli_query($conn,$select);
        if(mysqli_num_rows($result)>0){
            echo "<script>alert('Email Already Taken!')
            window.location.href='register.php'</script>";
        }else{
            $query="insert into users(name,email,password,phone,role)values
            ('$name','$email','$password','$number','$roletype')";
            $run=mysqli_query($conn,$query);
            if($run){
                 echo "<script>alert('Registration Successfully Done')
                    window.location.href='login.php'</script>";
            }else{
                echo "<script>alert('Registration Not Done')
                    window.location.href='register.php'</script>";
            }
        }
    }
?>